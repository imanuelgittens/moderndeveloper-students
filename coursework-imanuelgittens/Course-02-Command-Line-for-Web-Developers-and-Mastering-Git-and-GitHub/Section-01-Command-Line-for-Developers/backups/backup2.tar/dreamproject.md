After Modern Developer I would like to create a logistics platform (Similar to
UPS) with an API that can connect to online stores and allow these store owners
to offer the highest level of delivery service. 

This system will include package tracking and a tablet app that allows couriers
to accept digital signatures for successful fulfillment of orders. There is no
system like this made specifically for Trinidad and Tobago or the Caribbean as
yet so I would like to build one to give ecommerce in the region a big boost. 
