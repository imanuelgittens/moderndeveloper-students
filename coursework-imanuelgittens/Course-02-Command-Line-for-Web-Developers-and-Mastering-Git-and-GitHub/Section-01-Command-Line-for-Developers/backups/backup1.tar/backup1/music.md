I like to listen to reggae as well as positive rap music. 
